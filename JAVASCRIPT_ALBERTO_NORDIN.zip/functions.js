promptAlert();
function promptAlert() {
    window.alert("Be careful! A window prompt is going to pop up ...");
 }
 